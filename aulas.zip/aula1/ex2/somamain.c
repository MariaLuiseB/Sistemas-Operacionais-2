#include <stdio.h>
int soma(int, int);
int main()
{
    int r= soma(2,3);
    printf("2 + 3= %d",r);
    return 0;
}
