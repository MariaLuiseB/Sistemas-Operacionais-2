#define CLEAR_SCREEN "\x1b[2J" // LiMPA A TELA
//MOVE O CURSOR P/ LINHA 1 E COLUNA 1
#define CURSOR_UP_LEFT "\x1b[1;1H" // LINHA 1 COLUNA 1 

#define BOLD "\x1b[1m"

#define NORMAL "\x1b[0m"

#define COLOR_FG "\x1b[95m"

#define COLOR_BG "\x1b[106m"